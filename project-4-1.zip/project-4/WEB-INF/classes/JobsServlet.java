package Jobs;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/JobsServlet")
public class JobsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }

        Properties props = new Properties();
        try {
            props.load(getServletContext().getResourceAsStream("/WEB-INF/dataentryuser.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
        } catch (IOException e) {
            throw new ServletException("Failed to load database properties.", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String jnum = request.getParameter("jnum");
        String jname = request.getParameter("jname");
        String numworkers = request.getParameter("numworkers");
        String city = request.getParameter("city");

        if (jnum == null || jname == null || numworkers == null || city == null) {
            out.println("<p>Error: All fields must be filled. Please check your inputs.</p>");
            return;
        }

        try {
            int numWorkersInt = Integer.parseInt(numworkers);
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                 PreparedStatement pstmt = conn.prepareStatement("INSERT INTO jobs (jnum, jname, numworkers, city) VALUES (?, ?, ?, ?)")) {
                pstmt.setString(1, jnum);
                pstmt.setString(2, jname);
                pstmt.setInt(3, numWorkersInt);
                pstmt.setString(4, city);

                int updateCount = pstmt.executeUpdate();
                if (updateCount > 0) {
                    out.println("<p>New job record: (" + jnum + ", " + jname + ", " + numworkers + ", " + city + ") - successfully entered into database.</p>");
                } else {
                    out.println("<p>No records updated; please check input values.</p>");
                }
            }
        } catch (NumberFormatException | SQLException e) {
            out.println("<p>Error processing request: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }
    }
}
