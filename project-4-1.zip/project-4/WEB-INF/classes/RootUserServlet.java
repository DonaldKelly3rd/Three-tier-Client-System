package RootUser;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Properties;

@WebServlet("/RootUserServlet")
public class RootUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database properties
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver loaded successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }
        loadDatabaseProperties();
        testDatabaseConnection();
    }

    private void loadDatabaseProperties() throws ServletException {
        Properties props = new Properties();
        try {
            System.out.println("Loading database properties...");
            props.load(getServletContext().getResourceAsStream("/WEB-INF/root.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
            System.out.println("Database properties loaded successfully.");
        } catch (IOException e) {
            System.err.println("Failed to load database properties.");
            throw new ServletException("Failed to load database properties.", e);
        }
    }

    private void testDatabaseConnection() throws ServletException {
        System.out.println("Testing database connection...");
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            System.out.println("Connected to MySQL database successfully.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            throw new ServletException("Failed to connect to the database.", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sqlQuery = request.getParameter("sqlQuery").trim();
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            if (!(sqlQuery.toLowerCase().startsWith("select") || sqlQuery.toLowerCase().startsWith("insert") || sqlQuery.toLowerCase().startsWith("update"))) {
                out.println("<p>Only SELECT, INSERT, and UPDATE statements are allowed for root users.</p>");
                return;
            }

            executeSQLQuery(sqlQuery, response);
        }
    }

    private void executeSQLQuery(String sqlQuery, HttpServletResponse response) throws IOException {
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
             PreparedStatement pstmt = conn.prepareStatement(sqlQuery)) {
            boolean isResultSet = pstmt.execute();

            try (PrintWriter out = response.getWriter()) {
                if (isResultSet) {
                    ResultSet rs = pstmt.getResultSet();
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();

                    while (rs.next()) {
                        for (int i = 1; i <= columnCount; i++) {
                            out.print(rs.getString(i) + " ");
                        }
                        out.println("<br>");
                    }
                } else {
                    int updateCount = pstmt.getUpdateCount();
                    out.println("<p>Update successful. Rows affected: " + updateCount + "</p>");
                }
            }
        } catch (SQLException e) {
            System.err.println("SQL Exception occurred while executing the query: " + e.getMessage());
            try (PrintWriter out = response.getWriter()) {
                out.println("<p>Error executing SQL statement: " + e.getMessage() + "</p>");
            }
        }
    }
}
