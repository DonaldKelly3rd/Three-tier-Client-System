package AccountantUser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;


public class AccountantUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database properties
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver loaded successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }
        loadDatabaseProperties();
        testDatabaseConnection();
    }
    private void loadDatabaseProperties() throws ServletException {
        Properties props = new Properties();
        try {
            System.out.println("Loading database properties...");
            props.load(getServletContext().getResourceAsStream("/WEB-INF/theaccountant.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
            System.out.println("Database properties loaded successfully.");
        } catch (IOException e) {
            System.err.println("Failed to load database properties.");
            throw new ServletException("Failed to load database properties.", e);
        }
    }
    private void testDatabaseConnection() throws ServletException {
        System.out.println("Testing database connection...");
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            System.out.println("Connected to MySQL database successfully.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            throw new ServletException("Failed to connect to the database.", e);
        }
    }

   
    private Connection getDatabaseConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String command = request.getParameter("command");
        Object result = null;

        try (Connection conn = getDatabaseConnection();
             CallableStatement cStmt = conn.prepareCall(getStoredProcedureString(command))) {

            boolean hasResults = cStmt.execute();

            if (hasResults) {
                try (ResultSet rs = cStmt.getResultSet()) {
                    if (rs.next()) {
                        result = formatResultBasedOnCommand(command, rs);
                    }
                }
            } else {
                result = "No results returned.";
            }

        } catch (SQLException e) {
            result = "Error executing stored procedure: " + e.getMessage();
            e.printStackTrace();
        }

        request.setAttribute("result", result);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/theAccountantHome.jsp");
        dispatcher.forward(request, response);
    }

    private Object formatResultBasedOnCommand(String command, ResultSet rs) throws SQLException {
        switch (command) {
            case "maxStatus":
            case "totalWeight":
            case "totalShipment":
                return rs.getInt(1);  
            case "jobWithMostWorkers":
                String jobName = rs.getString("jname");
                int workerCount = rs.getInt("numworkers");
                return jobName + " - Workers: " + workerCount;
            case "StatusOfSupplier":
                StringBuilder builder = new StringBuilder();
                do {
                    builder.append(rs.getString("sname")).append(" - Status: ").append(rs.getString("status")).append("<br>");
                } while (rs.next());
                return builder.toString();
            default:
                throw new SQLException("Result format for command not defined");
        }
    }




    private String getStoredProcedureString(String command) {
        // Updated to handle all the provided stored procedure calls
        switch (command) {
            case "maxStatus":
                return "{CALL Get_The_Maximum_Status_Of_All_Suppliers()}";
            case "totalWeight":
                return "{CALL Get_The_Sum_Of_All_Parts_Weights()}";
            case "totalShipment":
                return "{CALL Get_The_Total_Number_Of_Shipments()}";
            case "jobWithMostWorkers":
                return "{CALL Get_The_Name_Of_The_Job_With_The_Most_Workers()}";
            case "StatusOfSupplier":
                return "{CALL List_The_Name_And_Status_Of_All_Suppliers()}";
            default:
                throw new IllegalArgumentException("Invalid command: " + command);
        }
    }
}