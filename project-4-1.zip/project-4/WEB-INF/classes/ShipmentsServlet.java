package Shipments;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/ShipmentsServlet")
public class ShipmentsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }

        Properties props = new Properties();
        try {
            props.load(getServletContext().getResourceAsStream("/WEB-INF/dataentryuser.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
        } catch (IOException e) {
            throw new ServletException("Failed to load database properties.", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String snum = request.getParameter("snum");
        String pnum = request.getParameter("pnum");
        String jnum = request.getParameter("jnum");
        String quantity = request.getParameter("quantity");

        if (snum == null || pnum == null || jnum == null || quantity == null) {
            out.println("<p>Error: All fields must be filled. Please check your inputs.</p>");
            return;
        }

        try {
            int quantityInt = Integer.parseInt(quantity);
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                 PreparedStatement pstmt = conn.prepareStatement("INSERT INTO shipments (snum, pnum, jnum, quantity) VALUES (?, ?, ?, ?)")) {
                pstmt.setString(1, snum);
                pstmt.setString(2, pnum);
                pstmt.setString(3, jnum);
                pstmt.setInt(4, quantityInt);

                int updateCount = pstmt.executeUpdate();
                if (updateCount > 0) {
                    out.println("<p>New shipment record: (" + snum + ", " + pnum + ", " + jnum + ", " + quantity + ") - successfully entered into database.</p>");
                }
            }
        } catch (NumberFormatException e) {
            out.println("<p>Error: Quantity must be an integer. Entered quantity: " + quantity + "</p>");
        } catch (SQLException e) {
            // Check for SQL state indicating a duplicate key error
            if (e.getSQLState().equals("23000")) {
                out.println("<p>Error: A shipment with the supplied 'snum' (" + snum + ") already exists in the database.</p>");
            } else {
                out.println("<p>Error processing request: " + e.getMessage() + "</p>");
            }
        }
    }
 }

