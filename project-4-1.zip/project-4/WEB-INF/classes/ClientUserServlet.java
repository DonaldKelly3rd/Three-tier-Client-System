package ClientUser;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@WebServlet("/ClientUserServlet")
public class ClientUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database properties
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver loaded successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }
        loadDatabaseProperties();
        testDatabaseConnection();
    }

    private void loadDatabaseProperties() throws ServletException {
        Properties props = new Properties();
        try {
            System.out.println("Loading database properties...");
            props.load(getServletContext().getResourceAsStream("/WEB-INF/client.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
            System.out.println("Database properties loaded successfully.");
        } catch (IOException e) {
            System.err.println("Failed to load database properties.");
            throw new ServletException("Failed to load database properties.", e);
        }
    }

    private void testDatabaseConnection() throws ServletException {
        System.out.println("Testing database connection...");
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            System.out.println("Connected to MySQL database successfully.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            throw new ServletException("Failed to connect to the database.", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sqlQuery = request.getParameter("sqlQuery").trim();

        // Check the response is in the correct format
        response.setContentType("text/html;charset=UTF-8");

        // Checking if the SQL query is a SELECT statement
        if (!sqlQuery.toLowerCase().startsWith("select")) {
            try(PrintWriter out = response.getWriter()) {
                out.println("<p>Only SELECT statements are allowed for clients.</p>");
            }
            return;
        }

        List<List<String>> resultList = executeSQLQuery(sqlQuery);

        try (PrintWriter out = response.getWriter()) {
            if (resultList.isEmpty()) {
                out.println("<p>No results found.</p>");
            } else {
                // Iterate through resultList to format the output
                resultList.forEach(row -> {
                    row.forEach(columnValue -> out.print(columnValue + " "));
                    out.println("<br>");
                });
            }
        }
    }

    private List<List<String>> executeSQLQuery(String sqlQuery) {
        List<List<String>> resultList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
             PreparedStatement pstmt = conn.prepareStatement(sqlQuery)) {
            ResultSet rs = pstmt.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (rs.next()) {
                List<String> row = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getString(i));
                }
                resultList.add(row);
            }
        } catch (SQLException e) {
            System.err.println("SQL Exception occurred while executing the query.");
            e.printStackTrace();
        }
        return resultList;
    }
}
