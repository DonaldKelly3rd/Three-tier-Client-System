package Parts;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/PartsServlet")
public class PartsServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    public void init() throws ServletException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Properties props = new Properties();
            props.load(getServletContext().getResourceAsStream("/WEB-INF/dataentryuser.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
        } catch (Exception e) {
            throw new ServletException("Initialization failed", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        System.out.println("Received pnum: " + request.getParameter("pnum")); // Log each parameter
        System.out.println("Received pname: " + request.getParameter("pname"));
        System.out.println("Received color: " + request.getParameter("color"));
        System.out.println("Received weight: " + request.getParameter("weight"));
        System.out.println("Received city: " + request.getParameter("city"));


        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            String pnum = request.getParameter("pnum");
            String pname = request.getParameter("pname");
            String color = request.getParameter("color");
            String weight = request.getParameter("weight");
            String city = request.getParameter("city");

            String sql = "INSERT INTO parts (pnum, pname, color, weight, city) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, pnum);
                pstmt.setString(2, pname);
                pstmt.setString(3, color);
                pstmt.setString(4, weight);
                pstmt.setString(5, city);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    out.println("<p>Record added successfully.</p>");
                } else {
                    out.println("<p>No records were added.</p>");
                }
            }
            updateResults(response, conn, out);
        } catch (SQLException e) {
            out.println("<p>SQL Error: " + e.getMessage() + "</p>");
            e.printStackTrace(out); // Output stack trace directly to the page for debugging
        }
    }

    private void updateResults(HttpServletResponse response, Connection conn, PrintWriter out) throws SQLException {
        try (PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM parts");
             ResultSet rs = pstmt.executeQuery()) {
            StringBuilder builder = new StringBuilder("<table border='1'>");
            builder.append("<tr><th>PNum</th><th>PName</th><th>Color</th><th>Weight</th><th>City</th></tr>");
            while (rs.next()) {
                builder.append("<tr>")
                       .append("<td>").append(rs.getString("pnum")).append("</td>")
                       .append("<td>").append(rs.getString("pname")).append("</td>")
                       .append("<td>").append(rs.getString("color")).append("</td>")
                       .append("<td>").append(rs.getString("weight")).append("</td>")
                       .append("<td>").append(rs.getString("city")).append("</td>")
                       .append("</tr>");
            }
            builder.append("</table>");
            out.print(builder.toString()); // Use the `out` variable to send data back
        }
    }
}
