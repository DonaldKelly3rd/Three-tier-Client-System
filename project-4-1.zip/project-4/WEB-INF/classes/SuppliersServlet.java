package Suppliers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/SuppliersServlet")
public class SuppliersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    //on runtime
    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver loaded successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }

        loadDatabaseProperties();
        testDatabaseConnection();
    }

    //load properties file
    private void loadDatabaseProperties() throws ServletException {
        Properties props = new Properties();
        try {
            props.load(getServletContext().getResourceAsStream("/WEB-INF/dataentryuser.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");
        } catch (IOException e) {
            throw new ServletException("Failed to load database properties.", e);
        }
    }

    
    //Test database connection
    private void testDatabaseConnection() throws ServletException {
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            System.out.println("Connected to MySQL database successfully.");
        } catch (SQLException e) {
            throw new ServletException("Failed to connect to the database.", e);
        }
    }

    //http request
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String snum = request.getParameter("snum");
        String sname = request.getParameter("sname");
        String statusString = request.getParameter("status");
        String city = request.getParameter("city");
        System.out.println("Received: snum=" + snum + ", sname=" + sname + ", status=" + statusString + ", city=" + city);

        //error handling
        if (snum == null || sname == null || statusString == null || city == null) {
            out.println("<p>Error: All fields must be filled. Please check your inputs.</p>");
            return;
        }

        try {
            int status = Integer.parseInt(statusString);
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                 PreparedStatement pstmt = conn.prepareStatement("INSERT INTO suppliers (snum, sname, status, city) VALUES (?, ?, ?, ?)")) {
                pstmt.setString(1, snum);
                pstmt.setString(2, sname);
                pstmt.setInt(3, status);
                pstmt.setString(4, city);

                int updateCount = pstmt.executeUpdate();
                if (updateCount > 0) {
                    out.println("<p>New supplier record: (" + snum + ", " + sname + ", " + status + ", " + city + ") - successfully entered into database.</p>");
                } else {
                    out.println("<p>No records updated; please check input values.</p>");
                }
            } catch (SQLException e) {
                out.println("<p>Failed to add the record to the database. SQL Error: " + e.getMessage() + "</p>");
                e.printStackTrace();
            }
        } catch (NumberFormatException e) {
            out.println("<p>Error: Status must be an integer. Entered status: " + statusString + "</p>");
            e.printStackTrace();
        }
    }
}
