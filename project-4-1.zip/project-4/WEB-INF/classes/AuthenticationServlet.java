package authentication;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletContext;

@WebServlet("/AuthenticationServlet")
public class AuthenticationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // Handle the ClassNotFoundException
            throw new ServletException("Failed to load MySQL JDBC driver.", e);
        }
        
        // Load database properties from systemlevel.properties file
        Properties props = new Properties();
        try {
            // Get the servlet context to access the file path
            ServletContext context = getServletContext();
            // Load the properties file using servlet context's getResourceAsStream() method
            props.load(context.getResourceAsStream("/WEB-INF/systemlevel.properties"));
            dbUrl = props.getProperty("db.url");
            dbUsername = props.getProperty("db.username");
            dbPassword = props.getProperty("db.password");

            // Check database connection
            testDatabaseConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    
    private void testDatabaseConnection() throws ServletException {
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            // Print a message to console indicating successful connection
            System.out.println("Connected to MySQL database successfully.");

            // Query to select all records from the usercredentials table
            String sql = "SELECT * FROM usercredentials";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                // Print the table contents
                System.out.println("User Credentials:");
                System.out.println("===================================");
                System.out.println("Username\tPassword");
                System.out.println("-----------------------------------");
                while (rs.next()) {
                    String username = rs.getString("login_username");
                    String password = rs.getString("login_password");
                    System.out.println(username + "\t\t" + password);
                }
                System.out.println("===================================");
            }
        } catch (SQLException e) {
            // Handle SQLException
            throw new ServletException("Failed to connect to the database.", e);
        }
    }
    
    
    //Get username and password from authenticate.html
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        // Debug: Print received username and password
        System.out.println("Received username: " + username);
        System.out.println("Received password: " + password);

        if (authenticateUser(username, password)) {
            redirectUser(username, response);
        } else {
            // Debug: Print a message indicating authentication failure
            System.out.println("Authentication failed for username: " + username);
            response.sendRedirect("error.html");
        }
    }


    private void redirectUser(String username, HttpServletResponse response) throws IOException {
        String destinationPage;

        switch (username) {
            case "root":
                destinationPage = "/Project4/jsp/RootHome.jsp";
                break;
            case "client":
                destinationPage = "/Project4/jsp/clientHome.jsp";
                break;
            case "dataentryuser":
                destinationPage = "/Project4/jsp/DataEntryUser.jsp";
                break;
            case "theaccountant":
                destinationPage = "/Project4/jsp/theAccountantHome.jsp";
                break;
            default:
                destinationPage = "/error.html";
                break;
        }

        String redirectURL = response.encodeRedirectURL(destinationPage);
        response.sendRedirect(redirectURL);
    }

 // Inside the authenticateUser method
    private boolean authenticateUser(String username, String password) {
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
            String sql = "SELECT * FROM usercredentials WHERE login_username = ? AND login_password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                
                // Debug: Print the SQL query being executed
                System.out.println("Executing SQL query: " + sql);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    boolean authenticated = rs.next();
                    
                    // Debug: Print authentication result
                    if (authenticated) {
                        System.out.println("Authentication successful for username: " + username);
                    } else {
                        System.out.println("Authentication failed for username: " + username);
                    }
                    
                    return authenticated;
                }
            }
        } catch (SQLException e) {
            // Debug: Print stack trace of any SQL exception
            e.printStackTrace();
        }
        return false;
    }
}
